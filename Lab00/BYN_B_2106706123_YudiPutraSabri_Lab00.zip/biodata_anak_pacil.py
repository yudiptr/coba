# Mencetak judul dari program ini
print('Biodata Anak Pacil 2021')

# Mengambil input dari pengguna dan
# menyimpannya ke dalam variabel-variabel
nama = input('Nama: ')
alamat = input('Alamat : ')
tanggal_lahir = input('Tanggal Lahir : ')
hobi = input('Hobi : ')
weight = input('Tinggi badan berapa iyh ?? ')
fav_food = input('Makanan Kesukaan?? ')

# Mencetak isi dari variabel-variabel
print()
print('Biodataku :')
print(nama)
print(alamat)
print(tanggal_lahir)
print(hobi)
print(weight)
print(fav_food)
